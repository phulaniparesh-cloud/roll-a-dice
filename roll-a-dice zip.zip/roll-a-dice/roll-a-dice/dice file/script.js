console.clear();
const color_1 = "silver";
const color_2 = "#2f2f2f";
const diceWidth = 200;
const diceHeight = diceWidth;
const pointWidth = diceWidth/6.66;
const pointHeight = pointWidth;

// Create a style element
const style = document.createElement("style");
// Append the style element to the head
document.head.append(style);
// Add the CSS to the style element
style.innerHTML = `

body{
--color-1: ${color_1};
--color-2: ${color_2};
margin: 0;
color: var(--color-2);
transition: color 1s;
}

.wrapper, .dice{
  margin: 0;
  width: 100vw;
  height: 100vh;
  background: var(--color-1);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  transition: background 1s;
}

.diceit {
background: var(--color-2);
color: var(--color-1);
padding: 5px 10px;
border-radius: 7px;
transition: color 1s, background 1s;
}

.dice:hover, .theme:hover {
  cursor: pointer;
}

.dice {
  position: relative;
  overflow: hidden;
  width: ${diceWidth}px;
  height: ${diceHeight}px;
  border-radius: 10px;
  background: var(--color-2);
  box-shadow: 0px 10px 17px -7px var(--color-2);
  animation: shake2 .4s ease-in-out;
  transition: background 1s, box-shadow 1s;
}

.point1, 
.point2, 
.point3,
.point4,
.point5,
.point6 {
  position: absolute;
  top: 150%;
  left: calc(50% - (${pointWidth}px/2));
  border-radius: 50%;
  width: ${pointWidth}px;
  height: ${pointHeight}px;
  background: var(--color-1);
  transition: top .8s, left .8s;
}
  ${ /* Middle-Position */'' }
.middle-middle {
  top: calc(50% - (${pointWidth}px/2));
  left: calc(50% - (${pointWidth}px/2));
}
  ${ /* Bottom-Left */'' }
.bottom-left{
  top: calc(80% - (${pointWidth}px));
  left: 20%;
}
  ${ /* Bottom-right */'' }
.bottom-right{
  top: calc(80% - (${pointWidth}px));
  left: calc(80% - (${pointWidth}px));
}

  ${ /* Top-Right */'' }
.top-right {
  top: 20%;
  left: calc(80% - (${pointWidth}px));
}

${ /* Top-Left */'' }
.top-left {
  top: 20%;
  left: 20%;
}

${ /* Left-Middle */'' }
.left-middle {
  top: calc(50% - (${pointWidth}px/2));
  left: 20%;
}

${ /* Right-Middle */'' }
.right-middle {
  top: calc(50% - (${pointWidth}px/2));
  left: calc(80% - (${pointWidth}px));
}

.shake-dice {
animation: shake .4s ease-in-out;
}

${ /* needed two keyframes for the same animation.. lol*/'' }
@keyframes shake {
0%{transform: rotate(0deg)}
25%{transform: rotate(20deg)}
50%{transform: rotate(-13deg); box-shadow: 0px 5px 10px -7px #2f2f2f;}
75%{transform: rotate(8deg)}
100%{transform: rotate(0deg)}
}
@keyframes shake2 {
0%{transform: rotate(0deg)}
25%{transform: rotate(17deg)}
50%{transform: rotate(-13deg); box-shadow: 0px 5px 10px -7px #2f2f2f;}
75%{transform: rotate(8deg)}
100%{transform: rotate(0deg)}
}

.theme {
  margin: 30px;
}
.theme:hover{
  opacity: 0.8;
}
`;

// Get the wrapper
const wrapper = document.querySelector(".wrapper");
// Create Dice
const dice = document.createElement("div");
wrapper.append(dice);
dice.classList.add("dice");

// Create Points
let count = 1;
//create 6 dots with class
for(i=0;i<6;i++){
  const pointClass = `point${count}`;
  const point = document.createElement("div");
  dice.append(point);
  point.classList.add("point");
  point.classList.add(pointClass);
  count++;
};

// Collect the Points
  const points = document.querySelectorAll(".point");
  const point1 = document.querySelector(".point1");
  const point2 = document.querySelector(".point2");
  const point3 = document.querySelector(".point3");
  const point4 = document.querySelector(".point4");
  const point5 = document.querySelector(".point5");
  const point6 = document.querySelector(".point6");

// click on wrapper event
dice.addEventListener("click", event => {
  //shake dice
  dice.classList.toggle("shake-dice");
  //random number 1-6
  let randomSix = Math.ceil(Math.random()*6);
  console.log(randomSix);
  
    points.forEach(point => {
      //reset points if toggled already
      if(point.classList.length > 1){
          point.classList.remove("top-left");
          point.classList.remove("top-right");
          point.classList.remove("left-middle");
          point.classList.remove("middle-middle");
          point.classList.remove("right-middle");
          point.classList.remove("bottom-left");
          point.classList.remove("bottom-right");
       }
    });
 
  
  if(randomSix === 1){
    //If a 1 is rolled
    point1.classList.add("middle-middle");
    point2.classList.add("middle-middle");
    point3.classList.add("middle-middle");
    point4.classList.add("middle-middle");
    point5.classList.add("middle-middle");
    point6.classList.add("middle-middle");
  } else if(randomSix === 2){
    //If a 2 is rolled
    point1.classList.add("bottom-left");
    point2.classList.add("bottom-left");
    point3.classList.add("bottom-left");
    point4.classList.add("top-right");
    point5.classList.add("top-right");
    point6.classList.add("top-right");
  } else if(randomSix === 3){
    //If a 3 is rolled
    point1.classList.add("bottom-left");
    point2.classList.add("bottom-left");
    point3.classList.add("middle-middle");
    point4.classList.add("middle-middle");
    point5.classList.add("top-right");
    point6.classList.add("top-right");
  } else if(randomSix === 4){
    //If a 4 is rolled
    point1.classList.add("top-left");
    point2.classList.add("top-right");
    point3.classList.add("bottom-right");
    point4.classList.add("bottom-left");
    point5.classList.add("top-right");
    point6.classList.add("top-left");
  } else if(randomSix === 5){
  //If a 5 is rolled
    point1.classList.add("top-left");
    point2.classList.add("top-right");
    point3.classList.add("bottom-right");
    point4.classList.add("bottom-left");
    point5.classList.add("top-right");
    point6.classList.add("middle-middle");
  } else if(randomSix === 6){
  //If a 6 is rolled
    point1.classList.add("top-left");
    point2.classList.add("top-right");
    point3.classList.add("bottom-right");
    point4.classList.add("bottom-left");
    point5.classList.add("right-middle");
    point6.classList.add("left-middle");
  }
  
});
  
// add color theme button
  const theme = document.createElement("div");
  wrapper.append(theme);
  theme.classList.add("theme");
  theme.innerHTML = `
    <svg style="width:24px;height:24px" viewBox="0 0 24 24">
    <path fill="currentColor" d="M12,18V6A6,6 0 0,1 18,12A6,6 0 0,1 12,18M20,15.31L23.31,12L20,8.69V4H15.31L12,0.69L8.69,4H4V8.69L0.69,12L4,15.31V20H8.69L12,23.31L15.31,20H20V15.31Z" />
</svg>
  `;
  // add color theme function
  let themeState = false;
  const body = document.querySelector("body");
  //rewrite color-variables based on themeState
  theme.addEventListener("click", event => {
    if(!themeState){
      body.style.setProperty("--color-1", color_2);
      body.style.setProperty("--color-2", color_1);
      themeState = true;
    } else if(themeState){
      body.style.setProperty("--color-1", color_1);
      body.style.setProperty("--color-2", color_2);
      themeState = false;
    }
  });